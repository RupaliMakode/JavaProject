package com.java.Anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("Bcom")
@Scope("prototype")
public class Bcom extends Student {
	public Bcom() {
		System.out.println("Bcom()....");
		System.out.println("----------------");
	}
	public void StartStudent() {
		System.out.println("Student is Bcom...");
	}

}
