package com.java.Anno;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("Engineer")
@Scope("prototype")
public class Engineer extends Student {
	public Engineer(){
		System.out.println("Engineer()....");
		System.out.println("-------------");
	}
	public void StartStudent() {
		System.out.println("Student is Engineer.....");
	}

}

