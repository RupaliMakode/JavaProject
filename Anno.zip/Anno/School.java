package com.java.Anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mySchool")
@Scope("prototype")
public class School 
{
	@Autowired
	@Qualifier("student")
	Student std1;
	
	@Autowired
	@Qualifier("Bcom")
	Student std2;
	
	
	@Autowired
	@Qualifier("Engineer")
	Student std3;
	
	
public School() {
	
	super();
	
	System.out.println("School is Started.....");
}


public void startSchool() {
	// TODO Auto-generated method stub
	
}

}
