package com.java.Anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("student")
@Scope("prototype")
public class Student  {
	public Student() {
		System.out.println("Student()......");
		
	}
	public static void startStudent() {
		System.out.println("Welcome to Student Section");
	}

}
