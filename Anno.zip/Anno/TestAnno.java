package com.java;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.java.Anno.School;
import com.java.Anno.Student;

import net.bytebuddy.build.Plugin.Engine.Source.Empty;

public class TestAnno {
	

	public static void main(String[] args) {
		
		ApplicationContext container = new ClassPathXmlApplicationContext("SpringAnnoConfig.xml");
		
		System.out.println("---- ------");
		System.out.println("Container is loaded......");
		
	School school = (School) container.getBean("mySchool");


	Student.startStudent();
	Student student = (Student) container.getBean("student");
//	School sch1 = (School) container.getBean("mySchool");
	
	Student student1 = (Student) container.getBean("Engineer");
	Student student2 = (Student) container.getBean("Bcom");
	
  }

	
	}
				



