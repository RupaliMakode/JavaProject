package com.java.orm;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.orm.Employee;

public class Delete {

	@Test
	public void empDeleteTest() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
	Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
	Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
	Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
		Employee emp = null;
		System.out.println("null POJO created...");

		emp= entityManager.find(Employee.class,111);
		emp= entityManager.find(Employee.class,11);
		emp= entityManager.find(Employee.class,121);
		
	Assertions.assertNotNull(emp);
		
		System.out.println("EMPNO : "+emp.getEmployeeNumber());
		System.out.println("EMPNAME  : "+emp.getEmployeeName());
		System.out.println("EMPSALARY  : "+emp.getEmployeeSalary());
	
		entityManager.remove(emp); // it will fire update query
		
		
		
		System.out.println("GOT THE POJO FROM DB..");
		System.out.println("RETRIEVED...");
		
		transaction.commit();
		System.out.println("Committed...");
				
		
	}
}
