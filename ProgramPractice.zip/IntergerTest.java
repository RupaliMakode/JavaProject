import com.java.Container.MyFloat;
import com.java.Container.MyInteger;

public class IntergerTest{
	public static void main(String[] args) {
		MyInteger mi = new MyInteger(40,20);
	   mi.print();     
	   mi.swap();
	   mi.print();
	   
	   System.out.println("-------");
	   MyFloat mf = new MyFloat(10.2f,20.1f);
	   mf.print();
	   mf.swap();
	   mf.print();
	   
	   System.out.println("------");
	   MyString ms = new MyString("core","java");
	   ms.print();
	   ms.swap();
	   ms.print();
	     
	   
	   System.out.println("------");
	   MyjukeBox mj = new MyjukeBox("Let me love you","abc");
	   mj.print();
	   mj.swap();
	   mj.print();
	     
		   
	   
	 
	}

}



class MyString
{
	 private String x;
	 private String y;
	
	
	public MyString(String x, String y) {
		super();
		this.x = x;
		this.y = y;
	}
	


	void swap() {
		System.out.println("swapping....");
	  String temp = x;
		x = y;
	    y = temp;
		
	}
	void print() {
		System.out.println("X "+x);
	    System.out.println("y "+y);
	}
	
}


class MyjukeBox
{
	 private String x;
	 private String y;
	
	public MyjukeBox(String string, String string2) {
		super();
		this.x = string;
		this.y = string2;
	}

	void swap() {
		System.out.println("swapping....");
		String temp = x;
		x = y;
	    y =temp;
		
	}
	void print() {
		System.out.println("X "+x);
	    System.out.println("y "+y);
	}
	
}
