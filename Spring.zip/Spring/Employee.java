package com.java;

public class Employee {
	int empno;
	String empname;
	  Double sal;
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public Double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
		
 
}
