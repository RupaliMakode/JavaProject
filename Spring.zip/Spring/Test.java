package com.java;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import net.bytebuddy.build.Plugin.Engine.Source.Empty;

public class Test {
	private static Employee Empno;

	public static void main(String[] args) {
		
		ApplicationContext container = new ClassPathXmlApplicationContext("SpringConfig.xml");
		Car theCar = (Car) container.getBean("mycar");
		theCar.startCar();
		
		
		System.out.println("----Department ------");
		
		Department theDepartment = (Department) container.getBean("mydept");
	  // theDepartment.setDeptno(1);
		System.out.println("dept no :"+theDepartment.getDeptno());
		
		//theDepartment.setDeptname("Hrithika");
		System.out.println("dept name :"+theDepartment.getDeptname());
		
		
		//theDepartment.setDeptloc("pune");
		  System.out.println("dept loc  :"+theDepartment.getDeptloc());
	
		  System.out.println("----Department 1------");
		
		Department theDepartment1 = (Department) container.getBean("mydept1");
		//theDepartment1.setDeptno(2);
		System.out.println("dept no :"+theDepartment1.getDeptno());
		
	//	theDepartment1.setDeptname("Nikita");
		System.out.println("dept name :"+theDepartment1.getDeptname());
		
		//theDepartment1.setDeptloc("Pune");
        System.out.println("dept loc  :"+theDepartment1.getDeptloc());
        
     System.out.println("-----Employee--------");
		
     Employee theEmployee =	(Employee) container.getBean("myemp");
		//theEmployee.setEmpno(101);
     System.out.println("emp no :"+theEmployee.getEmpno());
		
		
		//theEmployee.setEmpname("Ish");
		System.out.println("emp name : "+theEmployee.getEmpname());
		
		//theEmployee.setSal(4000);
		System.out.println("emp sal :"+theEmployee.getSal());
			
		 System.out.println("-----Employee 1--------");
			
	     Employee theEmployee1 = (Employee) container.getBean("myemp1");
			//theEmployee1.setEmpno(102);
			System.out.println("emp no :"+theEmployee1.getEmpno());
			
			//theEmployee1.setEmpname("Prisha");
			System.out.println("emp name : "+theEmployee1.getEmpname());
			
			//theEmployee1.setSal(5000);
			System.out.println("emp sal :"+theEmployee1.getSal());
				
		}
				
}


