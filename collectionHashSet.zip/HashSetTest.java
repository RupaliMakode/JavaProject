package com.java.Container;

import java.util.HashSet;

public class HashSetTest {
	public static void main(String[] args) {
		 
		
		HashSet<Integer> number.Set= new HashSet<Integer>();
		 number.add(10);
		 number.add(20);
		 number.add(30);
		 number.add(40);
		 number.add(50);
		 
		 
		 
	}


}
